const changePicButton = document.querySelector("#changePic");

changePicButton.addEventListener("click", (e)=>{

    $('.ui.modal').modal('show');



})